package com.cinelingo.player

import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var topBar: LinearLayout
    private lateinit var hud: TextView
    private var player: ExoPlayer? = null
    private lateinit var videoUri: Uri
    private var subtitleUri: Uri? = null

    private val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
    private var speedIdx = 2
    private val modes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    )
    private val modeNames = arrayOf("Fit", "Stretch", "Zoom")
    private var modeIdx = 0

    private lateinit var audio: AudioManager
    private var maxVol = 1
    private var volF = 0f
    private var startPos = 0L
    private var pendingSeek = -1L
    private var gestureMode = 0 // 0 none, 1 seek, 2 brightness, 3 volume
    private val handler = Handler(Looper.getMainLooper())

    private val pickSubtitle = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            applySubtitle(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = intent.data
        if (data == null) { finish(); return }
        videoUri = data
        setContentView(R.layout.activity_player)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        playerView = findViewById(R.id.player_view)
        topBar = findViewById(R.id.top_bar)
        hud = findViewById(R.id.hud)
        playerView.keepScreenOn = true
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = vis
        })

        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        val p = ExoPlayer.Builder(this).build()
        player = p
        playerView.player = p
        p.setMediaItem(MediaItem.fromUri(videoUri))
        val saved = getSharedPreferences("resume", MODE_PRIVATE).getLong(videoUri.toString(), 0L)
        if (saved > 0) p.seekTo(saved)
        p.prepare()
        p.play()

        findViewById<Button>(R.id.btn_sub).setOnClickListener { pickSubtitle.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btn_speed).setOnClickListener { b ->
            speedIdx = (speedIdx + 1) % speeds.size
            p.setPlaybackSpeed(speeds[speedIdx])
            (b as Button).text = "${speeds[speedIdx]}x"
        }
        findViewById<Button>(R.id.btn_aspect).setOnClickListener { b ->
            modeIdx = (modeIdx + 1) % modes.size
            playerView.resizeMode = modes[modeIdx]
            (b as Button).text = modeNames[modeIdx]
        }

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                startPos = player?.currentPosition ?: 0L
                pendingSeek = -1L
                gestureMode = 0
                volF = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) playerView.hideController() else playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val left = e.x < playerView.width / 2f
                val d = if (left) -10_000L else 10_000L
                player?.let { it.seekTo((it.currentPosition + d).coerceAtLeast(0L)) }
                showHud(if (left) "⏪ 10s" else "10s ⏩")
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (e1 == null) return false
                if (gestureMode == 0) {
                    gestureMode = when {
                        abs(e2.x - e1.x) > abs(e2.y - e1.y) -> 1
                        e1.x < playerView.width / 2f -> 2
                        else -> 3
                    }
                }
                val h = playerView.height.toFloat().coerceAtLeast(1f)
                when (gestureMode) {
                    1 -> {
                        val dur = player?.duration?.takeIf { it != C.TIME_UNSET } ?: Long.MAX_VALUE
                        val target = startPos + ((e2.x - e1.x) / playerView.width * 90_000).toLong()
                        pendingSeek = target.coerceIn(0L, dur)
                        showHud(fmt(pendingSeek))
                    }
                    2 -> {
                        val lp = window.attributes
                        val cur = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                        lp.screenBrightness = (cur + dy / h).coerceIn(0.02f, 1f)
                        window.attributes = lp
                        showHud("☀ ${(lp.screenBrightness * 100).roundToInt()}%")
                    }
                    3 -> {
                        volF = (volF + dy / h * maxVol * 1.2f).coerceIn(0f, maxVol.toFloat())
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, volF.roundToInt(), 0)
                        showHud("🔊 ${(volF / maxVol * 100).roundToInt()}%")
                    }
                }
                return true
            }
        })
        playerView.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            if (ev.action == MotionEvent.ACTION_UP || ev.action == MotionEvent.ACTION_CANCEL) {
                if (pendingSeek >= 0) player?.seekTo(pendingSeek)
                pendingSeek = -1L
                gestureMode = 0
            }
            true
        }
    }

    private fun applySubtitle(uri: Uri) {
        val p = player ?: return
        subtitleUri = uri
        val name = queryName(uri).lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val item = MediaItem.Builder().setUri(videoUri).setSubtitleConfigurations(listOf(sub)).build()
        val pos = p.currentPosition
        p.setMediaItem(item, pos)
        p.prepare()
        p.play()
        showHud("Subtitles loaded")
    }

    private fun queryName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: ""
            }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: ""
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = s % 3600 / 60; val x = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%02d:%02d".format(m, x)
    }

    private val hideHud = Runnable { hud.visibility = View.GONE }
    private fun showHud(t: String) {
        hud.text = t
        hud.visibility = View.VISIBLE
        handler.removeCallbacks(hideHud)
        handler.postDelayed(hideHud, 800)
    }

    override fun onStop() {
        super.onStop()
        player?.let {
            getSharedPreferences("resume", MODE_PRIVATE).edit()
                .putLong(videoUri.toString(), it.currentPosition).apply()
            it.pause()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}
