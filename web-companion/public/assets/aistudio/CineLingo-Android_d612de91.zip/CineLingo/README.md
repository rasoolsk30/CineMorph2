# CineLingo Player (Phase 1)

1. Android Studio -> File > Open -> select this CineLingo folder.
2. Let Gradle sync (accept any "update AGP/Gradle" prompt).
3. Run on a phone/emulator. Tap "Open video".

Features: ExoPlayer (Media3), double-tap +-10s, swipe left = brightness, swipe right = volume,
horizontal swipe = seek, speed, aspect ratio, external subtitles (.srt/.vtt/.ass), resume position,
"Open with" for any video file.
